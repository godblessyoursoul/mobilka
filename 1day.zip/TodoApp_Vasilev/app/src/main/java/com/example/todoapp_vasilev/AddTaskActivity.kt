package com.example.todoapp_vasilev

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.todoapp_vasilev.databinding.ActivityAddTaskBinding

class AddTaskActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddTaskBinding
    private var selectedDifficulty: Difficulty = Difficulty.EASY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAddTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Выделяем кнопку "Легкая" по умолчанию
        highlightDifficultyButton(binding.btnEasy)

        // Обработчики кнопок сложности
        binding.btnEasy.setOnClickListener {
            selectedDifficulty = Difficulty.EASY
            highlightDifficultyButton(binding.btnEasy)
        }
        binding.btnMedium.setOnClickListener {
            selectedDifficulty = Difficulty.MEDIUM
            highlightDifficultyButton(binding.btnMedium)
        }
        binding.btnHard.setOnClickListener {
            selectedDifficulty = Difficulty.HARD
            highlightDifficultyButton(binding.btnHard)
        }

        // Кнопка "Отмена" - просто закрываем экран
        binding.btnCancel.setOnClickListener {
            finish()
        }

        // Кнопка "Сохранить" - пока просто закрываем экран (без сохранения)
        binding.btnSave.setOnClickListener {
            finish()
        }
    }

    // Подсветка выбранной кнопки сложности
    private fun highlightDifficultyButton(selected: Button) {
        val blue = Color.parseColor("#2196F3")
        val gray = Color.parseColor("#E0E0E0")
        val white = Color.parseColor("#FFFFFF")
        val black = Color.parseColor("#000000")

        // Сбрасываем все кнопки
        binding.btnEasy.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnEasy.setTextColor(black)

        binding.btnMedium.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnMedium.setTextColor(black)

        binding.btnHard.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnHard.setTextColor(black)

        // Выделяем выбранную
        selected.backgroundTintList = ColorStateList.valueOf(blue)
        selected.setTextColor(white)
    }
}