package com.example.todoapp_vasilev

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.todoapp_vasilev.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: TaskAdapter
    private val tasks = TestDataGenerator.getTasks()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 1. Устанавливаем текущую дату
        updateDate()

        // 2. Настраиваем RecyclerView и адаптер
        binding.rvTasks.layoutManager = LinearLayoutManager(this)
        adapter = TaskAdapter(tasks) { updateStats() }
        binding.rvTasks.adapter = adapter

        // 3. Инициализация статистики
        updateStats()

        // 4. Настройка фильтров
        setupFilters()

        // 5. Обработчик кнопки "+" (пока просто заглушка)
        binding.fabAdd.setOnClickListener {
            val intent = android.content.Intent(this, AddTaskActivity::class.java)
            startActivity(intent)
        }

        // Отступы для системных панелей
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Метод для установки даты (формат: Вт, 9 дек. 2025г.)
    private fun updateDate() {
        val dateFormat = SimpleDateFormat("EEE, d MMM yyyyг.", Locale("ru"))
        binding.tvDate.text = dateFormat.format(Date())
    }

    // Метод обновления статистики (считает ВСЕ задачи, независимо от фильтра)
    private fun updateStats() {
        val total = tasks.size
        val completed = tasks.count { it.isCompleted }
        val active = total - completed
        val progress = if (total > 0) (completed * 100 / total) else 0

        binding.tvActiveCount.text = active.toString()
        binding.tvCompletedCount.text = completed.toString()
        binding.tvProgress.text = "$progress%"
    }

    // Настройка кнопок фильтра
    private fun setupFilters() {
        binding.btnFilterAll.setOnClickListener {
            adapter.setFilter(null)
            highlightButton(binding.btnFilterAll)
        }
        binding.btnFilterActive.setOnClickListener {
            adapter.setFilter(false)
            highlightButton(binding.btnFilterActive)
        }
        binding.btnFilterCompleted.setOnClickListener {
            adapter.setFilter(true)
            highlightButton(binding.btnFilterCompleted)
        }
        // По умолчанию выделяем "Все"
        highlightButton(binding.btnFilterAll)
    }

    // Визуальное выделение активной кнопки фильтра (ИСПРАВЛЕНО)
    private fun highlightButton(selected: Button) {
        val blue = Color.parseColor("#2196F3")
        val gray = Color.parseColor("#E0E0E0")
        val white = Color.parseColor("#FFFFFF")
        val black = Color.parseColor("#000000")

        // Сбрасываем все кнопки в серый цвет
        binding.btnFilterAll.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnFilterAll.setTextColor(black)

        binding.btnFilterActive.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnFilterActive.setTextColor(black)

        binding.btnFilterCompleted.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnFilterCompleted.setTextColor(black)

        // Выделяем выбранную кнопку синим цветом
        selected.backgroundTintList = ColorStateList.valueOf(blue)
        selected.setTextColor(white)
    }
}