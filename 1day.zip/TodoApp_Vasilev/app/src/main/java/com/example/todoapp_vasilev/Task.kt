package com.example.todoapp_vasilev

// Перечисление для уровня сложности
enum class Difficulty {
    EASY,   // Легкая
    MEDIUM, // Средняя
    HARD    // Сложная
}

// Модель данных задачи
data class Task(
    val id: Int,              // Уникальный номер
    val title: String,        // Заголовок
    val description: String,  // Описание
    var isCompleted: Boolean, // Статус выполнения
    val difficulty: Difficulty // Сложность
)