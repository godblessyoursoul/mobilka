package com.example.todoapp_vasilev

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapp_vasilev.databinding.TaskItemBinding

class TaskAdapter(
    private var tasks: MutableList<Task>,
    private val onTaskUpdated: () -> Unit // Колбэк для обновления статистики
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    // Фильтр: null = все, true = выполненные, false = активные
    private var filter: Boolean? = null

    class TaskViewHolder(val binding: TaskItemBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = TaskItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return getFilteredTasks().size
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = getFilteredTasks()[position]
        val binding = holder.binding

        // Заполняем данные
        binding.tvTaskTitle.text = task.title
        binding.tvTaskDesc.text = task.description

        // Настройка чекбокса: зачеркивание и прозрачность для выполненных
        binding.cbComplete.isChecked = task.isCompleted
        updateTaskAppearance(binding, task)

        // Обработчик чекбокса
        binding.cbComplete.setOnCheckedChangeListener { _, isChecked ->
            task.isCompleted = isChecked
            updateTaskAppearance(binding, task)
            onTaskUpdated() // Обновляем статистику сверху
        }

        // Обработчик удаления
        binding.btnDelete.setOnClickListener {
            val originalPosition = tasks.indexOf(task)
            if (originalPosition != -1) {
                tasks.removeAt(originalPosition)
                notifyItemRemoved(originalPosition)
                notifyItemRangeChanged(originalPosition, tasks.size)
                onTaskUpdated()
                Toast.makeText(it.context, "Задача удалена", Toast.LENGTH_SHORT).show()
            }
        }

        // Цвет индикатора сложности
        val color = when (task.difficulty) {
            Difficulty.EASY -> ContextCompat.getColor(holder.itemView.context, android.R.color.holo_green_light)
            Difficulty.MEDIUM -> ContextCompat.getColor(holder.itemView.context, android.R.color.holo_orange_light)
            Difficulty.HARD -> ContextCompat.getColor(holder.itemView.context, android.R.color.holo_red_light)
        }
        binding.tvDifficulty.text = when (task.difficulty) {
            Difficulty.EASY -> "Легкая"
            Difficulty.MEDIUM -> "Средняя"
            Difficulty.HARD -> "Сложная"
        }
        binding.tvDifficulty.setBackgroundColor(color)
    }

    // Вспомогательный метод: внешний вид задачи
    private fun updateTaskAppearance(binding: TaskItemBinding, task: Task) {
        if (task.isCompleted) {
            binding.tvTaskTitle.paintFlags = binding.tvTaskTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            binding.tvTaskDesc.paintFlags = binding.tvTaskDesc.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            binding.tvTaskTitle.alpha = 0.5f
            binding.tvTaskDesc.alpha = 0.5f
        } else {
            binding.tvTaskTitle.paintFlags = binding.tvTaskTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            binding.tvTaskDesc.paintFlags = binding.tvTaskDesc.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            binding.tvTaskTitle.alpha = 1.0f
            binding.tvTaskDesc.alpha = 1.0f
        }
    }

    // Метод фильтрации
    fun setFilter(showCompleted: Boolean?) {
        filter = showCompleted
        notifyDataSetChanged()
    }

    // Получение отфильтрованного списка
    private fun getFilteredTasks(): List<Task> {
        return when (filter) {
            true -> tasks.filter { it.isCompleted }
            false -> tasks.filter { !it.isCompleted }
            null -> tasks
        }
    }

    // Метод для получения всех задач (нужен для статистики)
    fun getAllTasks(): List<Task> = tasks
}