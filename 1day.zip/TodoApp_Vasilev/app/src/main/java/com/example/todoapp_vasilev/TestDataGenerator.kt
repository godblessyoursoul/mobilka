package com.example.todoapp_vasilev

object TestDataGenerator {

    fun getTasks(): MutableList<Task> {
        return mutableListOf(
            Task(1, "Купить молоко", "Зайти в магазин по пути домой", false, Difficulty.EASY),
            Task(2, "Сделать лабораторную", "Закончить код до вторника", false, Difficulty.HARD),
            Task(3, "Позвонить бабушке", "Узнать как дела", true, Difficulty.MEDIUM),
            Task(4, "Прочитать книгу", "Глава 1-3", false, Difficulty.MEDIUM),
            Task(5, "Убрать комнату", "Вытереть пыль и пропылесосить", true, Difficulty.EASY)
        )
    }
}