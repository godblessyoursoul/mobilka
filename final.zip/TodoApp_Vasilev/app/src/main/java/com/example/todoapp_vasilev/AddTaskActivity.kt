package com.example.todoapp_vasilev

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.todoapp_vasilev.databinding.ActivityAddTaskBinding

class AddTaskActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddTaskBinding
    private var selectedDifficulty: Difficulty = Difficulty.EASY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAddTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        highlightDifficultyButton(binding.btnEasy)

        // Обработчики кнопок сложности
        binding.btnEasy.setOnClickListener {
            selectedDifficulty = Difficulty.EASY
            highlightDifficultyButton(binding.btnEasy)
        }
        binding.btnMedium.setOnClickListener {
            selectedDifficulty = Difficulty.MEDIUM
            highlightDifficultyButton(binding.btnMedium)
        }
        binding.btnHard.setOnClickListener {
            selectedDifficulty = Difficulty.HARD
            highlightDifficultyButton(binding.btnHard)
        }

        // Кнопка "Отмена"
        binding.btnCancel.setOnClickListener {
            finish()
        }

        // Кнопка "Сохранить"
        binding.btnSave.setOnClickListener {
            val title = binding.etTitle.text.toString().trim()
            val description = binding.etDescription.text.toString().trim()

            if (title.isEmpty()) {
                binding.tilTitle.error = "Введите название"
                return@setOnClickListener
            } else {
                binding.tilTitle.error = null
            }

            // Возвращаем результат в MainActivity
            val resultIntent = Intent()
            resultIntent.putExtra("task_title", title)
            resultIntent.putExtra("task_description", description)
            resultIntent.putExtra("task_difficulty", selectedDifficulty.name)

            setResult(RESULT_OK, resultIntent)
            finish()
        }
    }

    private fun highlightDifficultyButton(selected: Button) {
        val blue = Color.parseColor("#2196F3")
        val gray = Color.parseColor("#E0E0E0")
        val white = Color.parseColor("#FFFFFF")
        val black = Color.parseColor("#000000")

        binding.btnEasy.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnEasy.setTextColor(black)
        binding.btnMedium.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnMedium.setTextColor(black)
        binding.btnHard.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnHard.setTextColor(black)

        selected.backgroundTintList = ColorStateList.valueOf(blue)
        selected.setTextColor(white)
    }
}