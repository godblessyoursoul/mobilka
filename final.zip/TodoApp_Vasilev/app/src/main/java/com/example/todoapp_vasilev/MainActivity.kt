package com.example.todoapp_vasilev

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.content.res.ColorStateList
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.todoapp_vasilev.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: TaskAdapter
    private lateinit var taskViewModel: TaskViewModel

    companion object {
        private const val ADD_TASK_REQUEST_CODE = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 1. Инициализация ViewModel
        taskViewModel = ViewModelProvider(this)[TaskViewModel::class.java]

        // 2. Устанавливаем текущую дату
        updateDate()

        // 3. Настраиваем RecyclerView и адаптер
        binding.rvTasks.layoutManager = LinearLayoutManager(this)

        // 🔥 ПЕРЕДАЁМ ЛЯМБДУ ДЛЯ УДАЛЕНИЯ
        adapter = TaskAdapter(
            onTaskChecked = { task -> taskViewModel.toggleTaskCompletion(task) },
            onTaskLongClick = { task -> showDeleteConfirmation(task) }
        )
        binding.rvTasks.adapter = adapter

        // 4. Подписка на изменения данных
        taskViewModel.tasks.observe(this) { tasks ->
            adapter.updateTasks(tasks)
            updateStats(tasks)
        }

        // 5. Настройка фильтров
        setupFilters()

        // 6. Обработчик кнопки "+"
        binding.fabAdd.setOnClickListener {
            val intent = Intent(this, AddTaskActivity::class.java)
            startActivityForResult(intent, ADD_TASK_REQUEST_CODE)
        }

        // Отступы для системных панелей
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Обработка результата из AddTaskActivity
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == ADD_TASK_REQUEST_CODE && resultCode == RESULT_OK) {
            val title = data?.getStringExtra("task_title") ?: ""
            val description = data?.getStringExtra("task_description") ?: ""
            val difficultyStr = data?.getStringExtra("task_difficulty") ?: "EASY"

            val difficulty = when (difficultyStr) {
                "MEDIUM" -> Difficulty.MEDIUM
                "HARD" -> Difficulty.HARD
                else -> Difficulty.EASY
            }

            if (title.isNotEmpty()) {
                val newTask = Task(
                    title = title,
                    description = description,
                    isCompleted = false,
                    difficulty = difficulty
                )
                taskViewModel.addTask(newTask)
            }
        }
    }

    // 🔥 ДИАЛОГ ПОДТВЕРЖДЕНИЯ УДАЛЕНИЯ
    private fun showDeleteConfirmation(task: Task) {
        AlertDialog.Builder(this)
            .setTitle("Удаление задачи")
            .setMessage("Вы уверены, что хотите удалить эту задачу?")
            .setPositiveButton("Удалить") { _, _ ->
                taskViewModel.deleteTask(task)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // Метод для установки даты
    private fun updateDate() {
        val dateFormat = SimpleDateFormat("EEE, d MMM yyyyг.", Locale("ru"))
        binding.tvDate.text = dateFormat.format(Date())
    }

    // Метод обновления статистики
    private fun updateStats(tasks: List<Task>) {
        val total = tasks.size
        val completed = tasks.count { it.isCompleted }
        val active = total - completed
        val progress = if (total > 0) (completed * 100 / total) else 0

        binding.tvActiveCount.text = active.toString()
        binding.tvCompletedCount.text = completed.toString()
        binding.tvProgress.text = "$progress%"
    }

    // Настройка кнопок фильтра
    private fun setupFilters() {
        binding.btnFilterAll.setOnClickListener {
            adapter.setFilter(null)
            highlightButton(binding.btnFilterAll)
        }
        binding.btnFilterActive.setOnClickListener {
            adapter.setFilter(false)
            highlightButton(binding.btnFilterActive)
        }
        binding.btnFilterCompleted.setOnClickListener {
            adapter.setFilter(true)
            highlightButton(binding.btnFilterCompleted)
        }
        highlightButton(binding.btnFilterAll)
    }

    // Визуальное выделение активной кнопки фильтра
    private fun highlightButton(selected: Button) {
        val blue = Color.parseColor("#2196F3")
        val gray = Color.parseColor("#E0E0E0")
        val white = Color.parseColor("#FFFFFF")
        val black = Color.parseColor("#000000")

        binding.btnFilterAll.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnFilterAll.setTextColor(black)
        binding.btnFilterActive.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnFilterActive.setTextColor(black)
        binding.btnFilterCompleted.backgroundTintList = ColorStateList.valueOf(gray)
        binding.btnFilterCompleted.setTextColor(black)

        selected.backgroundTintList = ColorStateList.valueOf(blue)
        selected.setTextColor(white)
    }
}