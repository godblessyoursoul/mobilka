package com.example.todoapp_vasilev

import androidx.room.Entity
import androidx.room.PrimaryKey

// Перечисление для уровня сложности
enum class Difficulty {
    EASY,   // Легкая
    MEDIUM, // Средняя
    HARD    // Сложная
}

// Модель данных задачи (сущность базы данных)
@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Int = 0, // ID генерируется автоматически
    val title: String,        // Заголовок
    val description: String,  // Описание
    var isCompleted: Boolean, // Статус выполнения
    val difficulty: Difficulty // Сложность
)