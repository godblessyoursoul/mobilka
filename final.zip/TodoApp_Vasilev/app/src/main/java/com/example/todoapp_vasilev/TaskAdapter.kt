package com.example.todoapp_vasilev

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapp_vasilev.databinding.TaskItemBinding

class TaskAdapter(
    private val onTaskChecked: (Task) -> Unit,
    private val onTaskLongClick: (Task) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    private var tasks: List<Task> = emptyList()
    private var filter: Boolean? = null

    class TaskViewHolder(val binding: TaskItemBinding) : RecyclerView.ViewHolder(binding.root)

    // Метод обновления списка задач
    fun updateTasks(newTasks: List<Task>) {
        tasks = newTasks
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = TaskItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TaskViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return getFilteredTasks().size
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = getFilteredTasks()[position]
        val binding = holder.binding

        binding.tvTaskTitle.text = task.title
        binding.tvTaskDesc.text = task.description

        // Настройка чекбокса
        binding.cbComplete.isChecked = task.isCompleted
        updateTaskAppearance(binding, task)

        // Обработчик чекбокса
        binding.cbComplete.setOnCheckedChangeListener { _, isChecked ->
            if (task.isCompleted != isChecked) {
                onTaskChecked(task)
            }
        }

        // 🔥 ОБРАБОТЧИК ДОЛГОГО НАЖАТИЯ (ДЛЯ УДАЛЕНИЯ)
        binding.root.setOnLongClickListener {
            onTaskLongClick(task)
            true // Возвращаем true, чтобы показать, что событие обработано
        }

        // Цвет индикатора сложности
        val color = when (task.difficulty) {
            Difficulty.EASY -> ContextCompat.getColor(holder.itemView.context, android.R.color.holo_green_light)
            Difficulty.MEDIUM -> ContextCompat.getColor(holder.itemView.context, android.R.color.holo_orange_light)
            Difficulty.HARD -> ContextCompat.getColor(holder.itemView.context, android.R.color.holo_red_light)
        }
        binding.tvDifficulty.text = when (task.difficulty) {
            Difficulty.EASY -> "Легкая"
            Difficulty.MEDIUM -> "Средняя"
            Difficulty.HARD -> "Сложная"
        }
        binding.tvDifficulty.setBackgroundColor(color)
    }

    // Внешний вид выполненной задачи
    private fun updateTaskAppearance(binding: TaskItemBinding, task: Task) {
        if (task.isCompleted) {
            binding.tvTaskTitle.paintFlags = binding.tvTaskTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            binding.tvTaskDesc.paintFlags = binding.tvTaskDesc.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            binding.tvTaskTitle.alpha = 0.5f
            binding.tvTaskDesc.alpha = 0.5f
        } else {
            binding.tvTaskTitle.paintFlags = binding.tvTaskTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            binding.tvTaskDesc.paintFlags = binding.tvTaskDesc.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            binding.tvTaskTitle.alpha = 1.0f
            binding.tvTaskDesc.alpha = 1.0f
        }
    }

    // Фильтрация
    fun setFilter(showCompleted: Boolean?) {
        filter = showCompleted
        notifyDataSetChanged()
    }

    private fun getFilteredTasks(): List<Task> {
        return when (filter) {
            true -> tasks.filter { it.isCompleted }
            false -> tasks.filter { !it.isCompleted }
            null -> tasks
        }
    }
}