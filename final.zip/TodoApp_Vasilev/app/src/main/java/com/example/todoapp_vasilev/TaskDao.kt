package com.example.todoapp_vasilev

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {

    // Получение всех задач (поток данных)
    @Query("SELECT * FROM tasks ORDER BY id DESC")
    fun getAllTasks(): Flow<List<Task>>

    // Вставка задачи
    @Insert
    suspend fun insert(task: Task)

    // Обновление задачи
    @Update
    suspend fun update(task: Task)

    // Удаление задачи
    @Delete
    suspend fun delete(task: Task)
}